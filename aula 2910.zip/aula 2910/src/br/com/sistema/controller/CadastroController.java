package br.com.sistema.controller;

import br.com.sistema.model.UsuarioModel;
import br.com.sistema.view.CadastroView;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class CadastroController {
    private CadastroView view;
    private UsuarioModel model;

    public CadastroController(CadastroView view, UsuarioModel model) {
        this.view = view;
        this.model = model;

        // Carrega os dados existentes no banco ao abrir a aplicação
        carregarTabelaInicial();

        // Configura o evento do botão de cadastrar
        this.view.addCadastrarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarCadastro();
            }
        });
    }

    private void carregarTabelaInicial() {
        List<String> usuarios = model.getUsuarios();
        for (int i = 0; i < usuarios.size(); i++) {
            view.adicionarLinha(i + 1, usuarios.get(i));
        }
    }

    private void realizarCadastro() {
        String nome = view.getNomeDigitado();

        if (nome.isEmpty()) {
            view.exibirMensagem("Digite um nome válido!", Color.RED);
            return;
        }

        // Salva no banco de dados
        model.adicionarUsuario(nome);

        // Atualiza a tabela na interface
        int novoId = model.getTotalUsuarios();
        view.adicionarLinha(novoId, nome);

        view.exibirMensagem("Cadastrado com sucesso!", new Color(0, 128, 0));
        view.limparCampo();
    }
}